# Urban Shadows
The old vanilla experience for _"Scriptorium"_. A _mystery_ adventure.
Just a DEMO for tha game.

### _Italy, 2016_
A new case for the renowned detective – the player – spirals out of control after a brutal murder and organ theft.

At first, it was just another case. Another corpse, another puzzle to solve. But then, the air grew heavy, the streets twisted in ways they shouldn’t, and shadows stretched where no light should cast them. I wasn’t alone. Something watched, something followed.

Join Fred and Jessie, uncover the truth behind the crime, and try to escape its consequences.
Urban Shadows will push you beyond your comfort zone and leave you truly alone until the very end—if you make it that far.

## Content Warning
This game contains intense themes, horror elements, and suggestive content. Player discretion is advised.

## Rating 12+
- Alcohol references
- Violence
- Gore

## Credits
- **Author:** Markel Rosco